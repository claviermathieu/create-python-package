def bonjour():
    print("Bonjour")
